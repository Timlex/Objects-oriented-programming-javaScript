package com.company;

public class MyPoint {
    private double x, y;

    // Constructors
    public MyPoint() {
        // no-arg generates a MyPoint with origin as its coordinates
        this(0, 0);
    }

    public MyPoint(double x, double y) {
        // generates a MyPoint with coordinates (x,y)
        this.x = x;
        this.y = y;
    }

    // Accessors
    public double getX() {
        return this.x;
    }

    public double getY() {
        return this.y;
    }

    // Functions
    public double distance(double x, double y) {
        // method to determine distance from current MyPoint object to a set of coordinates
        return Math.sqrt(Math.pow(x - this.x, 2) + Math.pow(y - this.y, 2));
    }

    public double distance(MyPoint point) {
        // passing coordinates of a MyPoint object as parameters to find distance
        return distance(point.getX(), point.getY());
    }

    public static double distance(MyPoint mp1, MyPoint mp2) {
        return Math.sqrt(Math.pow((mp1.x - mp2.x), 2)
                + Math.pow((mp1.y - mp2.y), 2));
    }

    // Output and Testing
    public String toString() {
        return "(x,y) = (" + x + "," + y + ")";
    }
}
