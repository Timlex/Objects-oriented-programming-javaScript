package com.company;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        System.out.println("""
                This program creates a point at (0,0) and a point at the coordinates\s
                entered by you. It then computes and displays the distance from (0,0)
                to the point defined by you, using three different methods.""");
        // Creates an Scanner to get inputs
        Scanner input = new Scanner(System.in);

        // Declares variable for point 1 and 2
        MyPoint p1 = new MyPoint(0,0);
        System.out.print("Enter the x coordinate of a point: ");
        int number1 = input.nextInt();
        System.out.print("Enter the y coordinate of a point: ");
        int number2 = input.nextInt();
        MyPoint p2 = new MyPoint(number1,number2);

        System.out.printf("Using method 1, the distance from (0,0) to (%d,%d) is %.2f%n", number1, number2, p1.distance(number1,number2));
        System.out.printf("Using method 2, the distance from (0,0) to (%d,%d) is %.2f%n", number1, number2, p1.distance(p2));
        System.out.printf("Using method 3, the distance from (0,0) to (%d,%d) is %.2f%n", number1, number2, p1.distance(number1, number2));


        System.out.println("Goodbye...");


    }
}

