package com.company;

public class Hourly extends Employee {
    //Instance variables

    private double hourlyWage;
    private double hoursWorked;

    public Hourly()
    {

    }

    public Hourly(String name, int serialNumber, double hourlyWage, double hoursWorked) {
        super(name, serialNumber);
        this.hourlyWage = hourlyWage;
        this.hoursWorked = hoursWorked;
    }

    public double getHourlyWage() {
        return hourlyWage;
    }

    public double getHoursWorked() {
        return hoursWorked;
    }

    public double getGrossPay()
    {
        return hourlyWage*hoursWorked;
    }

    public double getFedWithholding()
    {
        return 0.15*getGrossPay();
    }

    public double getStateWithholding()
    {
        return 0.07*getGrossPay();
    }


}
