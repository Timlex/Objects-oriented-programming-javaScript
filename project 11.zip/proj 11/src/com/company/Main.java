package com.company;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {

        Object arrayList = null;

        ArrayList<Employee> employees=new ArrayList<Employee>();

                //Create employees
                Hourly he1=new Hourly("Harry Hacker", 123, 15, 30);
                Hourly he2=new Hourly("Isabel Intern", 233, 12.5, 20);
                Salaried se=new Salaried("Cathy Coder", 611, 80000);
                //Add employees to list
                employees.add(he1);
                employees.add(he2);
                employees.add(se);
                System.out.println("Payroll Report");
                //Loop and print employee details
                for(Employee e:employees)
                {
                    System.out.printf("Employee:"+e.getName()+" Serial:"+e.getSerialNumber());
                    System.out.printf("Gross Pay: $%.2f",e.getGrossPay());
                    System.out.printf("Federal Withholding: $%.2f",e.getFedWithholding());
                    System.out.printf("State Withholding: $%.2f",e.getStateWithholding());
                    System.out.printf("Net Pay: $%.2f",(e.getGrossPay()-e.getFedWithholding()-e.getStateWithholding()));
                }

    }
}
