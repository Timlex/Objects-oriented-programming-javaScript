package com.company;

public class Salaried extends Employee {
    //Instance variables
    private double annualSalary;

    public Salaried()
    {

    }
    public Salaried(String name, int serialNumber, double annualSalary) {
        super(name, serialNumber);
        this.annualSalary = annualSalary;
    }

    public double getAnnualSalary() {
        return annualSalary;
    }

    public double getGrossPay()
    {
        return annualSalary / 52;
    }

    public double getFedWithholding()
    {
        return 0.15*getGrossPay();
    }

    public double getStateWithholding()
    {
        return 0.07*getGrossPay();
    }

}
