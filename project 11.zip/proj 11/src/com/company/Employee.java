package com.company;

public class Employee {
    //Instance variables
    private String name;
    private int serialNumber;

    public Employee() {

    }


    public Employee(String name, int serialNumber) {
        super();
        this.name = name;
        this.serialNumber = serialNumber;
    }

    public String getName() {
        return name;
    }

    public int getSerialNumber() {
        return serialNumber;
    }

    public double getGrossPay()
    {
        return 0;
    }

    public double getFedWithholding()
    {
        return 0;
    }

    public double getStateWithholding()
    {
        return 0;
    }
}