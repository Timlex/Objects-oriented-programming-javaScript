package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double[] x = new double[5];
        System.out.println("\nThis program computes the mean and the standard deviation for a set of numbers.");
        for(int i =0;i<5;i++)
        {
            System.out.print("Enter a numbers :");
            x[i] = input.nextDouble();
        }
        double Sol = mean(x);
        System.out.println("The mean of this set of numbers is "+Sol);
        double dev = deviation(x);
        double roundOff = Math.round(dev * 100.0) / 100.0;
        System.out.println("The standard deviation is "+roundOff);
        System.out.println("Goodbye");
    }
    public static double mean(double[ ] x)
    {
        double sum = 0;
        for(int i =0;i<5;i++)
        {
            sum = sum+x[i];
        }
        return sum/5;
    }
    public static double deviation(double[ ] x)
    {
        double summ = 0,sum=0;
        for(int i =0;i<5;i++)
        {
            summ = summ+x[i];
        }
        summ = summ/5;
        for(int i =0;i<5;i++)
        {
            sum+=Math.pow((x[i]-summ),2);
        }
        summ=sum/(4);
        double deviation=Math.sqrt(summ);
        return deviation;
    }
}