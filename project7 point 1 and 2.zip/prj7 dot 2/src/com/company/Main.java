package com.company;
public class Main {

    private static double[][] employeeHours=
            {
                    {0.0, 8.0, 8.0, 8.5, 8.0, 9.0, 0.0},
                    {0.0, 9.0, 9.0, 8.5, 8.0, 7.5, 0.0},
                    {0.0, 8.5, 8.0, 8.6, 8.6, 9.5, 2.0},
                    {0.0, 4.75, 6.0, 6.25, 6.5, 0.0, 0.0},
                    {0.0, 0.0, 0.0, 0.0, 5.25, 5.25, 6.0}
            };
    public static void main(String[] args) {
        String[] names = {"Tara Teamlead \t", "Harry Hacker\t", "Carl Coder\t\t",
                "Paula Programmer", "Darrin Debugger\t"};
        System.out.println("This Program computes the number of hours worked for a set of hourly employees.");
        System.out.println();
        System.out.println("Employee Name" + "\t\t\t" + "Total Hours");
        double[] totalHoursPerEmployee = sumEmployeeHours(employeeHours);
        for (int i = 0; i < totalHoursPerEmployee.length; i++) {

            System.out.print(names[i] + "\t\t\t");
            System.out.println(totalHoursPerEmployee[i]);
        }
        System.out.println("Goodbye");
    }
    public static double[] sumEmployeeHours(double[][] hours) {
        double[] totalHoursPerEmployee = new double[hours.length];
        for (int i = 0; i < hours.length; i++) {
            double sum = 0;
            for (double j = 0; j < hours[i].length; j++) {
                sum += hours[i][(int) j];
            }
            totalHoursPerEmployee[i] = sum;
        }
        return (totalHoursPerEmployee);
    }

    public static void setEmployeeHours(double[][] employeeHours) {
        Main.employeeHours = employeeHours;
    }
}
