package com.company;

public class Square extends Shape {
    private final double side;

    public Square(double side, int identifier){
        super(identifier);
        this.side=side;
    }
    //override
    public double Area(){
        return Math.pow(this.side,2);
    }
}
