package com.company;

public class Circle extends Shape {

    private final double radius;

    public Circle(double radius, int identifier){
        super(identifier);
        this.radius=radius;
    }
    //override
    public double Area(){
        return Math.PI*Math.pow(this.radius,2);
    }
}
