package com.company;

public class RightTriangle extends Shape {
    private final double height;
    private final double base;

    public RightTriangle(double height, double base, int identifier){
        super(identifier);
        this.height=height;
        this.base=base;
    }
    //override
    public double Area(){
        return 0.5*this.height*this.base;
    }
}

