package com.company;

public class Shape {
    private int identifier;
    private double height;
    private double base;

    public Shape(int identifier) {
        this.identifier = identifier;
    }

    public double Area() {
        double base_in = 0;
        double height_in = 0;
        return base_in * height_in * (1 / 2.0);

    }

    public int getIdentifier() {
        return this.identifier;
    }
}
