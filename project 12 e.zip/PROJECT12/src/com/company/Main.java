package com.company;
import java.text.DecimalFormat;
import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {


        ArrayList<Shape>list=new ArrayList();
        DecimalFormat df=new DecimalFormat("#.00");
        System.out.println("");
//polymorphism
        Shape obj1=new Circle(10, 156);
        Shape obj2=new Square(2,237);
        Shape obj3=new RightTriangle(3,4,212);
        list.add(obj1);
        list.add(obj2);
        list.add(obj3);
        System.out.print("Identifier Area");
        for (Shape shape : list) {
            System.out.print(" " + shape.getIdentifier() + " " + df.format(shape.Area()) + " sq. inches");
        }
    }
}

