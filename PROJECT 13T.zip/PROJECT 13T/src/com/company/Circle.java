package com.company;
import java.text.DecimalFormat;

class Circle extends GeometricFigure {
    private final double radius;
    public Circle(Point point, double radius, int identifier) {
        super(identifier, point);
        this.radius = radius;
    }

    @Override
    public void area() {
        DecimalFormat df = new DecimalFormat("0.00");
        double area = 3.1416 * radius * radius;
        System.out.println(getIdentifier() + "\t\t" + "\t" + getPoint() + "\t" + df.format(area) + " sq.inches");
    }

}
