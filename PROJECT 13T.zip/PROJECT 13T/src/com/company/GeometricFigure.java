package com.company;
import java.io.Serializable;

abstract class GeometricFigure implements Serializable {
    private final int identifier;
    private final Point point;

    public GeometricFigure(int identifier, Point point) {
        this.identifier = identifier;
        this.point = point;
    }
    public int getIdentifier() {
        return identifier;
    }

    public Point getPoint() {
        return point;
    }

    public abstract void area();

}

