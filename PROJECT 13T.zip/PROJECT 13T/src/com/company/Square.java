package com.company;
import java.text.DecimalFormat;

public class Square extends GeometricFigure {
    private final double side;
    public Square(Point point, double side, int identifier) {
        super(identifier, point);
        this.side = side;
    }

    @Override
    public void area() {
        DecimalFormat df = new DecimalFormat("0.00");
        double area = side * side;
        System.out.println(getIdentifier() + "\t\t" + "\t" + getPoint() + "\t" + df.format(area) + " sq.inches");
    }

}
