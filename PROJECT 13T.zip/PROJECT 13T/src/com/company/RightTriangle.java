package com.company;
import java.text.DecimalFormat;


public class RightTriangle extends GeometricFigure {
    private final double height;
    private final double base;

    public RightTriangle(Point point, double height, double base, int identifier) {
        super(identifier, point);
        this.height = height;
        this.base = base;
    }

    @Override
    public void area() {
        DecimalFormat df = new DecimalFormat("0.00");
        double area = (height * base) / 2;
        System.out.println(getIdentifier() + "\t\t" + "\t" + getPoint() + "\t" + df.format(area) + " sq.inches");
    }

}

