package com.company;
import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;

public class main {


    public static void main(String[] args) throws IOException, ClassNotFoundException {

        System.out.println("This program creates objects of classes Circle, Square and RightTriangle with their respective"
                + "values and stores them in an array list. It then calculates their areas. The GeometricFigure class is an abstract"
                + "class which the rest of the classes inherit from.");

        ArrayList<GeometricFigure> figures = new ArrayList<>();

        Point p1 = new Point(1, 1);
        Circle circle = new Circle(p1, 10, 156);

        Point p2 = new Point(1, 3);
        Square square = new Square(p2, 2, 237);

        Point p3 = new Point(3, 3);
        RightTriangle rightTriangle = new RightTriangle(p3, 3, 4, 212);

        figures.add(circle);
        figures.add(square);
        figures.add(rightTriangle);

        ObjectOutputStream output = new ObjectOutputStream(Files.newOutputStream(Paths.get("shapes.ser")));

        for (GeometricFigure shape : figures) {
            output.writeObject(shape);
        }
        output.close();


        System.out.println("Shape\t\tID\tPosition\tArea");

        ObjectInputStream input = new ObjectInputStream(Files.newInputStream(Paths.get("shapes.ser")));
        try {

            while (true) {
                GeometricFigure shape = (GeometricFigure) input.readObject();
                System.out.print(shape.getClass().getName() + "\t");
                shape.area();
            }
        } catch (EOFException endOfFileException) {
            input.close();
        }
    }
}
