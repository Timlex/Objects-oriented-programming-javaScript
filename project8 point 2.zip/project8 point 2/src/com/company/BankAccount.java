package com.company;

public class BankAccount {
    private double balance;

    public BankAccount(int i, double v) {
        ballance = 0;
    }

    public void makeWithdraw(double v) {
    }

    public String getBalance() {
        ;

    public void makeDeposit() {
    }

    public void makeDeposit() {
    }

    public void getAccountNumber() {
    }

    public void makeDeposit() {
    }