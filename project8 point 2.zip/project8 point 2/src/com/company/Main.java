package com.company;

public class Main {

    public static void main(String[] args) {
        System.out.println("This program tests the BankAccount class by ...\n" +
                "...Creating account number 123 with an initial balance of $5.00\n"
                +
                "...Making a deposit of $10.50\n" +
                "...Making a deposit of $3.25\n" +
                "...Making a withdrawal of $1.50");

        // Create an Account object with an account number of 123, and a balance of $5.00
        BankAccount account = new BankAccount(123,5.00);
        // Withdraw $1.50
        account.makeWithdraw(1.50);
        // Deposit $10.5 and 3.25
        account.makeDeposit(10.50, 3.25);
        // Display the balance, the monthly interest,
        // and the date when this account was created
        System.out.println("\n Account Statement");
        System.out.println("------------------------------------------");
        System.out.println("The balance in account number " +
                account.getAccountNumber() + " is "
                + account.getBalance());
        // Output a goodbye message
        System.out.println();
        System.out.println("Goodbye");
    }
}
