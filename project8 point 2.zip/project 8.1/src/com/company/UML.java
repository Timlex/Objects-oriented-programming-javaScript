package com.company;

public interface UML {
}
//UML Class Diagram
