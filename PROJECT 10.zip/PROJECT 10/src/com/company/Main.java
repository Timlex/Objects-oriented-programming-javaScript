package com.company;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter the colour of the triangle color(e.g red): ");
        String color = input.next();
        System.out.print("Is the triangle filled? y / n: ");
        String isFilledString = input.next();
        System.out.print("Enter the non-zero, positive lengths of the three sides of the triangle: ");
        double[] sides = new double[3];
        for (int i = 0; i < sides.length; i++) sides[i] = input.nextDouble();
        boolean isFilled = (isFilledString.equals("true"));

        Triangle t1 = null;
        try {
            t1 = new Triangle(sides[0], sides[1], sides[2]);
            t1.setColor(color);
            t1.setFilled(isFilled);
            System.out.println("Triangle side1 = 3.0, side2 = 4.0, side 3 = 5.0:");
            System.out.println("Color: = " + t1.getColor());
            System.out.println("Is filled? " + t1.isFilled());
            System.out.println("Area = " + t1.getArea());
        } catch (Triangle.IllegalTriangleException e) {
            e.printStackTrace();
        }
    }
}
