package com.company;

public abstract class GeometricObject {
    private String color;
    private boolean filled;

    public abstract double getArea();

    public void setColor(String color) {
        this.color = color;
    }

    public void setFilled(boolean filled) {
        this.filled = filled;
    }

    public String getColor() {

        return color;
    }

    public String isFilled() {
        return null;
    }
    
}
